package Liveasy.Loads;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoadsApplicationTests {

	@Test
	void contextLoads() {
	}

}
